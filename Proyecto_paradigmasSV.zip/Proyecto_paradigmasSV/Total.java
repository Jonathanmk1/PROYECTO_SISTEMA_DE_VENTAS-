
package Proyecto_paradigmasSV;

public interface Total {
    //y en donde pongo lo de total a pagar? en la claseprincipal o en sus hijas?
     public float TotalAPagar();
}
