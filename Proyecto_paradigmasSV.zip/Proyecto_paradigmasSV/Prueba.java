
package Proyecto_paradigmasSV;

public class Prueba {
    public static void main(String[] args) {
    FrmVentana fr = new FrmVentana();
    fr.setVisible(true);
    }
}
